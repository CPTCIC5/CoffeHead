import 'package:flutter/material.dart';
import 'package:flutter_application_1/product_details.dart';
import 'package:google_nav_bar/google_nav_bar.dart';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:smooth_page_indicator/smooth_page_indicator.dart';

class Home extends StatefulWidget {
  Home({Key? key}) : super(key: key);

  @override
  State<Home> createState() => _LoginState();
}

class _LoginState extends State<Home> {
  get callbackFunction => null;

  List Pictures = [
    'assets/images/a.jpg',
    'assets/images/b.jpg',
    'assets/images/c.jpg',
    'assets/images/hey.jpg'
  ];

  List values = [
    'assets/images/a.jpg',
    'assets/images/b.jpg',
    'assets/images/c.jpg',
    'assets/images/hey.jpg',
    'assets/images/a.jpg',
    'assets/images/b.jpg',
    'assets/images/c.jpg',
    'assets/images/hey.jpg',
    'assets/images/c.jpg',
    'assets/images/hey.jpg',
  ];
  List texts = ['Roadster', 'Nike', 'Hrx', 'Huetrap'];

  CarouselController buttonCarouselController = CarouselController();
  int activeindex = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        actions: [
          Icon(
            Icons.shopping_cart,
            color: Colors.black,
          )
        ],
        leading: CircleAvatar(
          backgroundImage: AssetImage('assets/images/Pratik bangar.png'),
        ),
        title: Center(
          child: Text(
            'Home',
            style: TextStyle(color: Colors.black),
          ),
        ),
      ),
      body: SingleChildScrollView(
        child: Column(children: [
          CarouselSlider(
              items: [
                Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10.0),
                    image: DecorationImage(
                        image: AssetImage('assets/images/2nd.jpeg')),
                  ),
                ),
                Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10.0),
                    image: DecorationImage(
                        image: AssetImage('assets/images/3rd.jpeg')),
                  ),
                ),
                Container(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(10.0),
                    image: DecorationImage(
                        image: AssetImage('assets/images/4th.jpeg')),
                  ),
                )
              ],
              carouselController: buttonCarouselController,
              options: CarouselOptions(
                height: 250,
                aspectRatio: 16 / 9,
                viewportFraction: 0.9,
                initialPage: 0,
                enableInfiniteScroll: true,
                reverse: false,
                autoPlay: true,
                autoPlayInterval: Duration(seconds: 3),
                autoPlayAnimationDuration: Duration(milliseconds: 800),
                autoPlayCurve: Curves.fastOutSlowIn,
                enlargeCenterPage: true,
                onPageChanged: (index, reason) =>
                    setState(() => activeindex = index),
                scrollDirection: Axis.horizontal,
              )),

          // SmoothIndicator(
          //   offset: 0,
          //   count: 3,
          // ),
          AnimatedSmoothIndicator(activeIndex: activeindex, count: 3),

          SizedBox(
            height: 20,
          ),
          Container(
            height: 100,
            child: Center(
              child: Text(
                'AWESOME DEALS',
                style: TextStyle(fontSize: 25),
              ),
            ),
          ),
          Container(
              height: 260,
              width: 400,
              child: ListView.separated(
                  shrinkWrap: true,
                  scrollDirection: Axis.horizontal,
                  itemCount: 4,
                  separatorBuilder: (context, _) => SizedBox(
                        width: 5,
                      ),
                  itemBuilder: ((context, index) =>
                      buildCard(Pictures[index], texts[index])))),

          Container(
            height: 100,
            child: Center(
              child: Text(
                'BUDGET BUYS',
                style: TextStyle(fontSize: 25),
              ),
            ),
          ),

          Container(
              height: 260,
              width: 400,
              child: ListView.separated(
                  shrinkWrap: true,
                  scrollDirection: Axis.horizontal,
                  itemCount: 4,
                  separatorBuilder: (context, _) => SizedBox(
                        width: 5,
                      ),
                  itemBuilder: ((context, index) =>
                      buildCard(Pictures[index], texts[index])))),

          Container(
            height: 100,
            child: Center(
              child: Text(
                'TOP BRAND ON OFFER',
                style: TextStyle(fontSize: 25),
              ),
            ),
          ),
          Container(
              height: 260,
              width: 400,
              child: ListView.separated(
                  shrinkWrap: true,
                  scrollDirection: Axis.horizontal,
                  itemCount: 4,
                  separatorBuilder: (context, _) => SizedBox(
                        width: 5,
                      ),
                  itemBuilder: ((context, index) =>
                      buildCard(Pictures[index], texts[index])))),

          Container(
            height: 100,
            child: Center(
              child: Text(
                'SHOP BY CATEGORY',
                style: TextStyle(fontSize: 25),
              ),
            ),
          ),
          Container(
            child: GridView.builder(
              physics: NeverScrollableScrollPhysics(),
              shrinkWrap: true,
              itemCount: 10,
              itemBuilder: (context, index) {
                return Card(
                  elevation: 3,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Center(
                        child: Image.asset(
                          values[index],
                          height: 170,
                          width: 200,
                        ),
                      ),
                      SizedBox(
                        height: 5,
                      ),
                      Container(
                          child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text('  Brand Name'),
                          SizedBox(
                            height: 2,
                          ),
                          Row(
                            children: [
                              Text('  300'),
                              Text(
                                '  (65% OFF)',
                                style: TextStyle(color: Colors.pink[300]),
                              ),
                            ],
                          )
                        ],
                      ))
                    ],
                  ),
                );
              },
              gridDelegate:
                  SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2),
            ),
          )
        ]),
      ),
    );
  }

  Widget buildCard(String imagename, String displayname) => GestureDetector(
        onTap: () {
          Navigator.push(context,
              MaterialPageRoute(builder: (context) => ProductDetails()));
        },
        child: Container(
          width: 150,
          height: 250,
          color: Colors.white,
          child: Card(
            elevation: 3,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Image.asset(
                  imagename,
                  fit: BoxFit.contain,
                ),
                Container(
                    child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('  ' + displayname),
                    SizedBox(
                      height: 2,
                    ),
                    Row(
                      children: [
                        Text('  300'),
                        Text(
                          '  (65% OFF)',
                          style: TextStyle(color: Colors.pink[300]),
                        ),
                      ],
                    )
                  ],
                ))
              ],
            ),
          ),
        ),
      );
}
