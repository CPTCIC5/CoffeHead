import 'package:flutter/material.dart';
import 'package:flutter/src/foundation/key.dart';
import 'package:flutter/src/widgets/framework.dart';
import 'package:flutter_application_1/wishlist.dart';
import 'package:flutter_application_1/signin.dart';
import 'package:flutter_application_1/home.dart';
import 'package:flutter_application_1/signup.dart';
import 'package:flutter_application_1/secondpage.dart';
import 'package:flutter_application_1/profile_screen.dart';
import 'package:google_nav_bar/google_nav_bar.dart';

class Navbar extends StatefulWidget {
  const Navbar({Key? key}) : super(key: key);

  @override
  State<Navbar> createState() => _NavbarState();
}

class _NavbarState extends State<Navbar> {
  int selectedIndex = 0;
  final tabs = [Home(), Wishlist(), secondpage(), Profile()];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      bottomNavigationBar: Container(
          color: Colors.white,
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 15),
            child: GNav(
                backgroundColor: Colors.white,
                activeColor: Colors.black,
                gap: 5,
                tabs: [
                  GButton(
                    padding: EdgeInsets.all(8),
                    icon: Icons.home,
                    backgroundColor: Colors.pink.shade100,
                    iconActiveColor: Colors.pinkAccent,
                    textColor: Colors.pinkAccent,
                    text: 'Home          ',
                    onPressed: () {
                      setState(() {
                        selectedIndex = 0;
                      });
                    },
                  ),
                  GButton(
                    padding: EdgeInsets.all(8),
                    icon: Icons.favorite,
                    backgroundColor: Colors.purple.shade100,
                    iconActiveColor: Colors.purple.shade400,
                    textColor: Colors.purple.shade400,
                    text: 'Wishlist       ',
                    onPressed: () {
                      setState(() {
                        selectedIndex = 1;
                      });
                    },
                  ),
                  GButton(
                    padding: EdgeInsets.all(8),
                    icon: Icons.shopping_cart,
                    backgroundColor: Colors.purple.shade100,
                    iconActiveColor: Colors.purple.shade400,
                    textColor: Colors.purple.shade400,
                    text: 'cart         ',
                    onPressed: () {
                      setState(() {
                        selectedIndex = 2;
                      });
                    },
                  ),
                  GButton(
                    padding: EdgeInsets.all(8),
                    icon: Icons.person_outlined,
                    backgroundColor: Colors.pink.shade100,
                    iconActiveColor: Colors.pinkAccent,
                    textColor: Colors.pinkAccent,
                    text: 'Profile       ',
                    onPressed: () {
                      setState(() {
                        selectedIndex = 3;
                      });
                    },
                  ),
                ]),
          )),
      body: tabs[selectedIndex],
    );
  }
}
