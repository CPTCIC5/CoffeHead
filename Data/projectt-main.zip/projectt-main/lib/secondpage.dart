import 'package:flutter/material.dart';

class secondpage extends StatelessWidget {
  const secondpage({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Center(child: Text('hey')),
        ),
        body: Container(
            height: 300,
            width: 400,
            child: ListView.separated(
                scrollDirection: Axis.horizontal,
                itemCount: 4,
                separatorBuilder: (context, _) => SizedBox(
                      width: 10,
                    ),
                itemBuilder: ((context, index) => buildCard()))));
  }

  Widget buildCard() => Container(
        width: 150,
        height: 200,
        color: Colors.green,
        child: Column(
          children: [
            Image.network(
                'https://images.unsplash.com/photo-1609179548370-a5ee66e7a69e?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxzZWFyY2h8Mnx8cGVyc29uJTIwc3RhbmRpbmd8ZW58MHx8MHx8&w=1000&q=80')
          ],
        ),
      );
}
