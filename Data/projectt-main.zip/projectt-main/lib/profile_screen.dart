import 'package:flutter/material.dart';
import 'package:flutter_application_1/signup.dart';
import 'package:fluttericon/typicons_icons.dart';
import 'package:fluttericon/fontelico_icons.dart';
import 'package:fluttericon/linecons_icons.dart';

final myIcons = const <Widget>[
  const Icon(Typicons.attention),
  const Icon(Fontelico.emo_wink),
  const Icon(Linecons.globe),
];

class Profile extends StatelessWidget {
  const Profile({Key? key}) : super(key: key);
  final double topContainerheight = 230;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.white,
          title: Center(
            child: Text(
              'Profile',
              style: TextStyle(color: Colors.black),
            ),
          ),
        ),
        body: SingleChildScrollView(
            child: Column(children: [
          Container(
            height: topContainerheight,
            child: Stack(children: [
              Column(
                children: [
                  Container(
                    height: topContainerheight * .58,
                    color: Colors.blueGrey,
                  ),
                  Container(
                    height: topContainerheight * .42,
                    color: Colors.white,
                  )
                ],
              ),
              Positioned(
                bottom: 20,
                left: 20,
                child: Container(
                  height: 132,
                  width: 132,
                  child: Card(
                    child: Image.asset(
                      'assets/images/profile1.png',
                    ),
                  ),
                ),
              ),
              Positioned(
                bottom: 22,
                left: 170,
                child: GestureDetector(
                  onTap: () {
                    Navigator.push(context,
                        MaterialPageRoute(builder: (context) => SignUp()));
                  },
                  child: Container(
                    padding: EdgeInsets.symmetric(vertical: 20),
                    width: 270,
                    color: Colors.pink[300],
                    // decoration:
                    //     BoxDecoration(border: Border.all(color: Colors.black)),

                    child: Center(
                        child: Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.shopping_cart_outlined, color: Colors.white),
                        Text('Login/Signup',
                            style: TextStyle(
                                fontWeight: FontWeight.bold,
                                color: Colors.white)),
                      ],
                    )),
                  ),
                ),
              )
            ]),
          ),
          SizedBox(
            height: 20,
          ),
          Container(
            child: Column(
              children: [
                SizedBox(
                    height: 80,
                    child: ListTile(
                        tileColor: Color.fromARGB(255, 239, 236, 236),
                        title: Text('Orders'),
                        subtitle: Text('Check your order status'),
                        leading: Icon(Icons.delivery_dining),
                        trailing: Icon(Icons.arrow_right_alt))),
                SizedBox(
                  height: 20,
                ),
                SizedBox(
                    height: 80,
                    child: ListTile(
                        tileColor: Color.fromARGB(255, 239, 236, 236),
                        title: Text('Wishlist'),
                        subtitle: Text('Your most loved style'),
                        leading: Icon(Icons.favorite),
                        trailing: Icon(Icons.arrow_right_alt))),
                SizedBox(
                  height: 20,
                ),
                ListTile(
                    tileColor: Color.fromARGB(255, 239, 236, 236),
                    title: Text('Gift Card'),
                    subtitle: Text('Your favourite gift cards'),
                    leading: Icon(Icons.card_giftcard),
                    trailing: Icon(Icons.arrow_right_alt)),
                SizedBox(
                  height: 20,
                ),
                ListTile(
                    tileColor: Color.fromARGB(255, 239, 236, 236),
                    title: Text('Logout'),
                    subtitle: Text('Logout is here'),
                    leading: Icon(Icons.logout),
                    trailing: Icon(Icons.arrow_right_alt))
              ],
            ),
          ),
          Center(
            child: TextButton(
              child: Text('Trendel.pvt'),
              onPressed: () {
                print('Pressed');
              },
            ),
          ),
          Center(
            child: TextButton(
              child: Text('Trendel.pvt'),
              onPressed: () {
                print('Pressed');
              },
            ),
          ),
        ])));
  }
}
