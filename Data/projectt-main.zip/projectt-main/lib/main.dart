import 'package:flutter/material.dart';
import 'package:flutter_application_1/wishlist.dart';
import 'package:flutter_application_1/signin.dart';
import 'package:flutter_application_1/home.dart';
import 'package:flutter_application_1/navbar.dart';
import 'package:flutter_application_1/signup.dart';
import 'package:flutter_application_1/secondpage.dart';
import 'package:flutter_application_1/profile_screen.dart';
import 'package:flutter_application_1/textbutton.dart';

void main() {
  runApp(MaterialApp(home: Navbar()));
}

class MyApp extends StatelessWidget {
  MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MaterialApp();
  }
}
