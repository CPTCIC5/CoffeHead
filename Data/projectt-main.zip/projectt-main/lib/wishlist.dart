import 'package:flutter/material.dart';
import 'package:google_nav_bar/google_nav_bar.dart';

class Wishlist extends StatelessWidget {
  Wishlist({Key? key}) : super(key: key);

  List values = [
    'assets/images/a.jpg',
    'assets/images/b.jpg',
    'assets/images/c.jpg',
    'assets/images/hey.jpg',
    'assets/images/a.jpg',
    'assets/images/b.jpg',
    'assets/images/c.jpg',
    'assets/images/hey.jpg',
    'assets/images/c.jpg',
    'assets/images/hey.jpg',
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.white,
        title: Center(
          child: Text(
            'Wishllist',
            style: TextStyle(color: Colors.black),
          ),
        ),
      ),
      body: Container(
        child: GridView.builder(
          itemCount: 10,
          itemBuilder: (context, index) {
            return Container(
              height: 250,
              child: Card(
                elevation: 3,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Center(
                      child: Image.asset(
                        values[index],
                        height: 170,
                      ),
                    ),
                    SizedBox(
                      height: 5,
                    ),
                    Container(
                        child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('  Brand Name'),
                        SizedBox(
                          height: 2,
                        ),
                        Row(
                          children: [
                            Text('  300'),
                            Text(
                              '  (65% OFF)',
                              style: TextStyle(color: Colors.pink[300]),
                            ),
                          ],
                        )
                      ],
                    )),
                    SizedBox(
                      height: 4,
                    ),
                    Container(
                      padding: EdgeInsets.symmetric(vertical: 20),
                      height: 61,
                      decoration: BoxDecoration(
                          border: Border.all(
                              color: Color.fromARGB(255, 108, 108, 108))),
                      child: Center(
                          child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(
                            Icons.shopping_cart_outlined,
                            color: Colors.pink[300],
                          ),
                          Text('Add to Bag',
                              style: TextStyle(
                                fontWeight: FontWeight.bold,
                                color: Colors.pink[300],
                              )),
                        ],
                      )),
                    ),
                  ],
                ),
              ),
            );
          },
          gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2, childAspectRatio: 0.8),
        ),
      ),
    );
  }
}
