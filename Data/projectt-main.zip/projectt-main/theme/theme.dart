import 'package:flutter/material.dart';

class AppColor {
  static Color WhiteColor = Color(0xffffffff);
}
